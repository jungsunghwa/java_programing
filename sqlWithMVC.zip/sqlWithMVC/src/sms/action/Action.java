package sms.action;

import java.util.Scanner;

public interface Action {
	public void excute(Scanner sc) throws Exception;
}
